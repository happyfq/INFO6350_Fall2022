//
//  DetailsTableViewCell.swift
//  getStockPrices
//
//  Created by Fq W on 12/10/22.
//

import UIKit
import Alamofire
import SwiftyJSON

class DetailsTableViewCell: UIViewCell {
    

    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var lblSymbol: UILabel!
    
    @IBOutlet weak var lblPrice: UILabel!
    var symbol = ""
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
//    func getAllValues(){
//        let url = "https://us-central1-whatsapp-analytics-2de0e.cloudfunctions.net/app/getstock?symbol=\(symbol)"
//        AF.request(url).responseJSON { responseData in
//                    if responseData.error != nil {
//                        print(responseData.error!)
//                        return
//                    }
//
//                    let stockJSON = JSON(responseData.data!)
//                    let stock = Stock()
//            stock.compan = stockJSON["companyName"].stringValue
//            stock.lbl = stockJSON["companyName"].stringValue
//            stock.lblName = stockJSON["companyName"].stringValue
//
//
//                    self.stocksInfo = [String]()
//                    for stock in stocks {
//                        let stockJSON = JSON(stock)
//                        let symbol = stockJSON["Symbol"].stringValue
//                        let price = stockJSON["Price"].stringValue
//                        let str = "Symbol: \(symbol) , \(price)"
//                        self.stocksInfo.append(str)
//
//                    }
//    }

}
